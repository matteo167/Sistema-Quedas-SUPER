import cv2
import os

def draw_circle_center(image):
    height, width, _ = image.shape
    center_x, center_y = int(width / 2), int(height / 2)
    radius = 50
    color = (0, 0, 255)  # Vermelho (BGR)

    cv2.circle(image, (center_x, center_y), radius, color, -1)

    return image

video_path = '11.mp4'
output_path = 'output.mp4'  # Nome do novo arquivo de vídeo de saída

# Obtenha as informações do vídeo de entrada para a criação do vídeo de saída
cap = cv2.VideoCapture(video_path)
fps = int(cap.get(cv2.CAP_PROP_FPS))
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Defina o codec e crie o objeto VideoWriter para salvar o vídeo
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_path, fourcc, fps, (frame_width, frame_height))

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = draw_circle_center(frame)

    # Salve o quadro com o círculo no novo vídeo
    out.write(frame)


cap.release()
out.release()  # Libere o objeto VideoWriter
cv2.destroyAllWindows()