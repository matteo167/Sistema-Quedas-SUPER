import cv2
import mediapipe as mp

mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.5)

video_path = '11.mp4'
cap = cv2.VideoCapture(video_path)

output_file = 'output.txt'
with open(output_file, 'w') as f:
    frame_count = 0

    while cap.isOpened():
        ret, image = cap.read()
        if not ret:
            break

        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = pose.process(image_rgb)

        if results.pose_landmarks:
            f.write(f'frame {frame_count}:\n')
            for idx, landmark in enumerate(results.pose_landmarks.landmark):
                f.write(f'{idx}.\n')
                f.write(f'x = {landmark.x}\n')
                f.write(f'y = {landmark.y}\n')
                f.write(f'z = {landmark.z}\n')
                f.write(f'visibility = {landmark.visibility}\n')
            f.write('\n')

        frame_count += 1

        cv2.imshow('MediaPipe Pose', image)
        if cv2.waitKey(1) & 0xFF == 27:
            break

cap.release()
cv2.destroyAllWindows()