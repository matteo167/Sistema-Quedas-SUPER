import cv2
import mediapipe as mp
import time
import math



def calcular_angulo_tri(ponto1, ponto2, ponto3):
    def calcular_vetor(p1, p2):
        return [p2[i] - p1[i] for i in range(3)]

    def calcular_produto_escalar(v1, v2):
        return sum(v1[i] * v2[i] for i in range(3))

    def calcular_modulo(vetor):
        return math.sqrt(sum(vetor[i]**2 for i in range(3)))

    vetor1 = calcular_vetor(ponto2, ponto1)
    vetor2 = calcular_vetor(ponto2, ponto3)

    produto_escalar = calcular_produto_escalar(vetor1, vetor2)
    modulo_vetor1 = calcular_modulo(vetor1)
    modulo_vetor2 = calcular_modulo(vetor2)

    angulo_radianos = math.acos(produto_escalar / (modulo_vetor1 * modulo_vetor2))
    angulo_graus = math.degrees(angulo_radianos)

    return angulo_graus


def calcular_angulo_bi(ponto1, ponto2, ponto3):
    def calcular_vetor(p1, p2):
        return [p2[i] - p1[i] for i in range(2)]

    def calcular_produto_escalar(v1, v2):
        return sum(v1[i] * v2[i] for i in range(2))

    def calcular_modulo(vetor):
        return math.sqrt(sum(vetor[i]**2 for i in range(2)))

    vetor1 = calcular_vetor(ponto2, ponto1)
    vetor2 = calcular_vetor(ponto2, ponto3)

    produto_escalar = calcular_produto_escalar(vetor1, vetor2)
    modulo_vetor1 = calcular_modulo(vetor1)
    modulo_vetor2 = calcular_modulo(vetor2)

    angulo_radianos = math.acos(produto_escalar / (modulo_vetor1 * modulo_vetor2))
    angulo_graus = math.degrees(angulo_radianos)

    return angulo_graus





def main():
    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose()

    cap = cv2.VideoCapture(0)

    last_print_time = 0

    while cap.isOpened():
        ret, frame = cap.read()

        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(image_rgb)

        if results.pose_landmarks:
            mp.solutions.drawing_utils.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
            current_time = time.time()
            if current_time - last_print_time >= 1:
                for idx, landmark in enumerate(results.pose_landmarks.landmark):
                    h, w, c = frame.shape
                    cx, cy = int(landmark.x * w), int(landmark.y * h)
                    print(f"{idx} - {round(landmark.x, 2)}, {round(landmark.y, 2)}, {round(landmark.z, 2)}")
                # ombroE = [results.pose_landmarks.landmark[11].x, results.pose_landmarks.landmark[11].y, results.pose_landmarks.landmark[11].z]
                # cotoveloE = [results.pose_landmarks.landmark[13].x, results.pose_landmarks.landmark[13].y, results.pose_landmarks.landmark[13].z]
                # pulsoE = [results.pose_landmarks.landmark[15].x, results.pose_landmarks.landmark[15].y, results.pose_landmarks.landmark[15].z]
                # print(ombroE)
                # print(cotoveloE)
                # print(pulsoE)
                # print(calcular_angulo_tri(ombroE, cotoveloE, pulsoE))

                print(results.pose_landmarks.landmark[15])

                ombroE = [results.pose_landmarks.landmark[11].x, results.pose_landmarks.landmark[11].y]
                cotoveloE = [results.pose_landmarks.landmark[13].x, results.pose_landmarks.landmark[13].y]
                pulsoE = [results.pose_landmarks.landmark[15].x, results.pose_landmarks.landmark[15].y]
                print(ombroE)
                print(cotoveloE)
                print(pulsoE)
                print(calcular_angulo_bi(ombroE, cotoveloE, pulsoE))

                last_print_time = current_time

        cv2.imshow('Pose Estimation', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()