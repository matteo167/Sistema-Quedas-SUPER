file_path = 'output.txt'

with open(file_path, 'r') as f:
    frame_count = 0
    for line in f:
        if line.startswith('frame'):
            print(f'Frame {frame_count}:')
            frame_count += 1
        print(line)